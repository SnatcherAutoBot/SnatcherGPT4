
const express = require('express');
const cors = require('cors');
const app = express();
const tasks = [];

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

app.get('/api/snkrs/tasks', (req, res) => {
  res.json(tasks);
});

app.post('/api/snkrs/tasks', (req, res) => {
  const task = req.body;
  task.id = tasks.length + 1;
  task.status = 'Mocked: Queue Joined';
  tasks.push(task);
  res.json(task);
});

app.delete('/api/snkrs/task/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = tasks.findIndex(t => t.id === id);
  if (index !== -1) tasks.splice(index, 1);
  res.json({ message: 'Task deleted' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
