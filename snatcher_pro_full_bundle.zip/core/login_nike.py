import asyncio
from playwright.async_api import async_playwright
import json
import os

SESSION_FILE = "nike_session.json"

async def login_to_nike(email, password):
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
            locale="en-US"
        )
        page = await context.new_page()

        # Navigate to Nike login page
        await page.goto("https://www.nike.com/login")

        # Wait and fill login form
        await page.fill("input[type=email]", email)
        await page.fill("input[type=password]", password)
        await page.click("button[type=submit]")

        # Wait for navigation or error
        await page.wait_for_timeout(5000)

        # Check if login succeeded
        if "login" not in page.url:
            print("✅ Login successful. Saving session...")
            storage = await context.storage_state()
            with open(SESSION_FILE, "w") as f:
                json.dump(storage, f)
        else:
            print("❌ Login failed. Check credentials or CAPTCHA.")

        await browser.close()

async def load_nike_session():
    if not os.path.exists(SESSION_FILE):
        print("No saved session. Run login first.")
        return None
    with open(SESSION_FILE, "r") as f:
        session_data = json.load(f)
    return session_data

# Example usage:
# asyncio.run(login_to_nike("your_email", "your_password"))
# session = asyncio.run(load_nike_session())
