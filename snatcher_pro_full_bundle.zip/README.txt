Snatcher Pro – SNKRS Ready Edition

This package includes:
- login_nike.py: Logs into your Nike account using Playwright with stealth settings
- snkrs_queue_entry.py: Loads a SNKRS product page and simulates queue join
- Session saved to nike_session.json

Run these in order:
1. login_nike.py (to save session)
2. snkrs_queue_entry.py (to simulate joining drop)

Make sure you have Python 3.8+ and run:
pip install playwright
playwright install
